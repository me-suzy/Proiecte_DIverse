/*
 * LichidarePlata.java
 *
 * Created on 28 iunie 2004, 16:03
 */

package UML;

/**
 *
 * @author  alex
 */
public class LichidarePlata {
    public double procent;
    /** Creates a new instance of LichidarePlata */
    public LichidarePlata() {
    }
    
}
