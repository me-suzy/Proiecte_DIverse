/*
 * Transe.java
 *
 * Created on 28 iunie 2004, 16:04
 */

package UML;

/**
 *
 * @author  alex
 */
public class Transe {
    public double procent;
    public float transa;
    /** Creates a new instance of Transe */
    public Transe() {
    }
    
}
